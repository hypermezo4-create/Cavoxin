# classes13.dex

.class public Lcom/paperos/settings/PaperOSGesture;
.super Lcom/android/settings/BaseSettingsPreferenceFragment;
.source "nextMonetControlFragment.java"


# static fields
.field private static final DEBUG:Z = true

.field private static final TAG:Ljava/lang/String; = "This Smali Specially modified for PaperOS ,Don\'t Forgot to give credit,if you not a unofficial child of your parent"


# instance fields
.field private monetPackageMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private overlayManager:Landroid/content/om/IOverlayManager;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 26
    invoke-direct {p0}, Lcom/android/settings/BaseSettingsPreferenceFragment;-><init>()V

    .line 24
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    .line 27
    const-string v0, "overlay"

    invoke-static {v0}, Landroid/os/ServiceManager;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Landroid/content/om/IOverlayManager$Stub;->asInterface(Landroid/os/IBinder;)Landroid/content/om/IOverlayManager;

    move-result-object v0

    iput-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->overlayManager:Landroid/content/om/IOverlayManager;

    .line 28
    return-void
.end method

.method private DEBUG(Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 4
    .param p1, "message"  # Ljava/lang/String;
    .param p2, "e"  # Ljava/lang/Exception;

    .line 198
    const-string v0, "This Smali Specially modified for PaperOS ,Don\'t Forgot to give credit,if you not a unofficial child of your parent"

    invoke-static {v0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 200
    return-void
.end method

.method private disableOverlay(Ljava/lang/String;)V
    .registers 5
    .param p1, "packageName"  # Ljava/lang/String;

    .line 185
    :try_start_0
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->overlayManager:Landroid/content/om/IOverlayManager;

    if-eqz v0, :cond_23

    .line 186
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->overlayManager:Landroid/content/om/IOverlayManager;

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1, v1}, Landroid/content/om/IOverlayManager;->setEnabled(Ljava/lang/String;ZI)Z

    .line 187
    const-string v0, "This Smali Specially modified for PaperOS ,Don\'t Forgot to give credit,if you not a unofficial child of your parent"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Overlay disabled: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_29

    .line 189
    :cond_23
    const-string v0, "OverlayManager service is null"

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/paperos/settings/PaperOSGesture;->DEBUG(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_29
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_29} :catch_2a

    .line 193
    :goto_29
    goto :goto_41

    .line 191
    :catch_2a
    move-exception v0

    .line 192
    .local v0, "e":Landroid/os/RemoteException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Failed to disable overlay: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1, v0}, Lcom/paperos/settings/PaperOSGesture;->DEBUG(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 194
    .end local v0  # "e":Landroid/os/RemoteException;
    :goto_41
    return-void
.end method

.method private enableOverlay(Ljava/lang/String;)V
    .registers 5
    .param p1, "packageName"  # Ljava/lang/String;

    .line 172
    :try_start_0
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->overlayManager:Landroid/content/om/IOverlayManager;

    if-eqz v0, :cond_24

    .line 173
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->overlayManager:Landroid/content/om/IOverlayManager;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1, v1, v2}, Landroid/content/om/IOverlayManager;->setEnabled(Ljava/lang/String;ZI)Z

    .line 174
    const-string v0, "This Smali Specially modified for PaperOS ,Don\'t Forgot to give credit,if you not a unofficial child of your parent"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Overlay enabled: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2a

    .line 176
    :cond_24
    const-string v0, "OverlayManager service is null"

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/paperos/settings/PaperOSGesture;->DEBUG(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_2a
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_2a} :catch_2b

    .line 180
    :goto_2a
    goto :goto_42

    .line 178
    :catch_2b
    move-exception v0

    .line 179
    .local v0, "e":Landroid/os/RemoteException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Failed to enable overlay: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1, v0}, Lcom/paperos/settings/PaperOSGesture;->DEBUG(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 181
    .end local v0  # "e":Landroid/os/RemoteException;
    :goto_42
    return-void
.end method

.method private handleGlobalMonetToggle(Z)V
    .registers 7
    .param p1, "isEnabled"  # Z

    .line 132
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 133
    .local v1, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 134
    .local v2, "packageName":Ljava/lang/String;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {p0, v3}, Lcom/paperos/settings/PaperOSGesture;->findPreference(Ljava/lang/CharSequence;)Landroidx/preference/Preference;

    move-result-object v3

    check-cast v3, Landroidx/preference/XMiuiCheckBoxPreference;

    .line 136
    .local v3, "individualSwitch":Landroidx/preference/XMiuiCheckBoxPreference;
    if-eqz v3, :cond_39

    invoke-virtual {v3}, Landroidx/preference/XMiuiCheckBoxPreference;->isChecked()Z

    move-result v4

    if-eqz v4, :cond_39

    .line 137
    if-eqz p1, :cond_36

    .line 138
    invoke-direct {p0, v2}, Lcom/paperos/settings/PaperOSGesture;->enableOverlay(Ljava/lang/String;)V

    goto :goto_39

    .line 140
    :cond_36
    invoke-direct {p0, v2}, Lcom/paperos/settings/PaperOSGesture;->disableOverlay(Ljava/lang/String;)V

    .line 143
    .end local v1  # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    .end local v2  # "packageName":Ljava/lang/String;
    .end local v3  # "individualSwitch":Landroidx/preference/XMiuiCheckBoxPreference;
    :cond_39
    :goto_39
    goto :goto_a

    .line 144
    :cond_3a
    return-void
.end method

.method private initializeMonetPackages()V
    .registers 4

    .line 49
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_androidbluetooth"

    const-string v2, "com.paperos.monet.androidbluetooth"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_aod"

    const-string v2, "com.paperos.monet.aod"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_backup"

    const-string v2, "com.paperos.monet.backup"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_bluetooth"

    const-string v2, "com.paperos.monet.bluetooth"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_bugreport"

    const-string v2, "com.paperos.monet.bugreport"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_calendar"

    const-string v2, "com.paperos.monet.calendar"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_cloudservice"

    const-string v2, "com.paperos.monet.cloudservice"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_camera"

    const-string v2, "com.paperos.monet.camera"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_cleanmaster"

    const-string v2, "com.paperos.monet.cleanmaster"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_cloudbackup"

    const-string v2, "com.paperos.monet.cloudbackup"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_contacts"

    const-string v2, "com.paperos.monet.contacts"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_calculator"

    const-string v2, "com.paperos.monet.calculator"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_deskclock"

    const-string v2, "com.paperos.monet.deskclock"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_downloads"

    const-string v2, "com.paperos.monet.downloads"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_extraphoto"

    const-string v2, "com.paperos.monet.extraphoto"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_finddevice"

    const-string v2, "com.paperos.monet.finddevice"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_fileexplorer"

    const-string v2, "com.paperos.monet.fileexplorer"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_freeform"

    const-string v2, "com.paperos.monet.freeform"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_gallery"

    const-string v2, "com.paperos.monet.gallery"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_home"

    const-string v2, "com.paperos.monet.home"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_incallui"

    const-string v2, "com.paperos.monet.incallui"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_miinput"

    const-string v2, "com.paperos.monet.miinput"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_misound"

    const-string v2, "com.paperos.monet.misound"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_milink_service"

    const-string v2, "com.paperos.monet.milink_service"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_mirror"

    const-string v2, "com.paperos.monet.mirror"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_mishare"

    const-string v2, "com.paperos.monet.mishare"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_mediaeditor"

    const-string v2, "com.paperos.monet.mediaeditor"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_miservice"

    const-string v2, "com.paperos.monet.miservice"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_misettings"

    const-string v2, "com.paperos.monet.misettings"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_mms"

    const-string v2, "com.paperos.monet.mms"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_notes"

    const-string v2, "com.paperos.monet.notes"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_notification"

    const-string v2, "com.paperos.monet.notification"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_personalassistant"

    const-string v2, "com.paperos.monet.personalassistant"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_packageinstaller"

    const-string v2, "com.paperos.monet.packageinstaller"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_powerkeeper"

    const-string v2, "com.paperos.monet.powerkeeper"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_permission"

    const-string v2, "com.paperos.monet.permission"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_phone"

    const-string v2, "com.paperos.monet.phone"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_settings"

    const-string v2, "com.paperos.monet.settings"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_screenrecorder"

    const-string v2, "com.paperos.monet.screenrecorder"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_server_telecom"

    const-string v2, "com.paperos.monet.server_telecom"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_screenshot"

    const-string v2, "com.paperos.monet.screenshot"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_securitycenter"

    const-string v2, "com.paperos.monet.securitycenter"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_scanner"

    const-string v2, "com.paperos.monet.scanner"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 105
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_securitycore"

    const-string v2, "com.paperos.monet.securitycore"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 106
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_systemui"

    const-string v2, "com.paperos.monet.systemui"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_systemuiplugin"

    const-string v2, "com.paperos.monet.systemuiplugin"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_soundrecorder"

    const-string v2, "com.paperos.monet.soundrecorder"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_touchassistant"

    const-string v2, "com.paperos.monet.touchassistant"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_thememanager"

    const-string v2, "com.paperos.monet.thememanager"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_updater"

    const-string v2, "com.paperos.monet.updater"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_weather2"

    const-string v2, "com.paperos.monet.weather2"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    const-string v1, "paperos_monet_xiaomiaccount"

    const-string v2, "com.paperos.monet.xiaomiaccount"

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    return-void
.end method

.method private setupGlobalMonetSwitch()V
    .registers 3

    .line 121
    const-string v0, "paperos_switch_monet_color"

    invoke-virtual {p0, v0}, Lcom/paperos/settings/PaperOSGesture;->findPreference(Ljava/lang/CharSequence;)Landroidx/preference/Preference;

    move-result-object v0

    check-cast v0, Landroidx/preference/XMiuiCheckBoxPreference;

    .line 122
    .local v0, "globalMonetSwitch":Landroidx/preference/XMiuiCheckBoxPreference;
    if-eqz v0, :cond_12

    .line 123
    new-instance v1, Lcom/paperos/settings/PaperOSGesture$0;

    invoke-direct {v1, p0}, Lcom/paperos/settings/PaperOSGesture$0;-><init>(Lcom/paperos/settings/PaperOSGesture;)V

    invoke-virtual {v0, v1}, Landroidx/preference/XMiuiCheckBoxPreference;->setOnPreferenceChangeListener(Landroidx/preference/Preference$OnPreferenceChangeListener;)V

    .line 129
    :cond_12
    return-void
.end method

.method private setupIndividualMonetSwitch(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "preferenceKey"  # Ljava/lang/String;
    .param p2, "packageName"  # Ljava/lang/String;

    .line 156
    invoke-virtual {p0, p1}, Lcom/paperos/settings/PaperOSGesture;->findPreference(Ljava/lang/CharSequence;)Landroidx/preference/Preference;

    move-result-object v0

    check-cast v0, Landroidx/preference/XMiuiCheckBoxPreference;

    .line 157
    .local v0, "checkBoxPreference":Landroidx/preference/XMiuiCheckBoxPreference;
    if-eqz v0, :cond_10

    .line 158
    new-instance v1, Lcom/paperos/settings/PaperOSGesture$1;

    invoke-direct {v1, p0, p2}, Lcom/paperos/settings/PaperOSGesture$1;-><init>(Lcom/paperos/settings/PaperOSGesture;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroidx/preference/XMiuiCheckBoxPreference;->setOnPreferenceChangeListener(Landroidx/preference/Preference$OnPreferenceChangeListener;)V

    .line 168
    :cond_10
    return-void
.end method

.method private setupIndividualMonetSwitches()V
    .registers 5

    .line 147
    iget-object v0, p0, Lcom/paperos/settings/PaperOSGesture;->monetPackageMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_26

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 148
    .local v1, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 149
    .local v2, "preferenceKey":Ljava/lang/String;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 151
    .local v3, "packageName":Ljava/lang/String;
    invoke-direct {p0, v2, v3}, Lcom/paperos/settings/PaperOSGesture;->setupIndividualMonetSwitch(Ljava/lang/String;Ljava/lang/String;)V

    .line 152
    .end local v1  # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>;"
    .end local v2  # "preferenceKey":Ljava/lang/String;
    .end local v3  # "packageName":Ljava/lang/String;
    goto :goto_a

    .line 153
    :cond_26
    return-void
.end method


# virtual methods
.method protected getPreferenceScreenResId()I
    .registers 1

    const p0, 0x7f1802a6

    return p0
.end method

.method synthetic lambda$setupGlobalMonetSwitch$0$com-android-internal-util-paperos-xml-paperosMonet(Landroidx/preference/Preference;Ljava/lang/Object;)Z
    .registers 5
    .param p1, "preference"  # Landroidx/preference/Preference;
    .param p2, "newValue"  # Ljava/lang/Object;

    .line 124
    move-object v0, p2

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 125
    .local v0, "isEnabled":Z
    invoke-direct {p0, v0}, Lcom/paperos/settings/PaperOSGesture;->handleGlobalMonetToggle(Z)V

    .line 126
    const/4 v1, 0x1

    return v1
.end method

.method synthetic lambda$setupIndividualMonetSwitch$1$com-android-internal-util-paperos-xml-paperosMonet(Ljava/lang/String;Landroidx/preference/Preference;Ljava/lang/Object;)Z
    .registers 6
    .param p1, "packageName"  # Ljava/lang/String;
    .param p2, "preference"  # Landroidx/preference/Preference;
    .param p3, "newValue"  # Ljava/lang/Object;

    .line 159
    move-object v0, p3

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 160
    .local v0, "isEnabled":Z
    if-eqz v0, :cond_d

    .line 161
    invoke-direct {p0, p1}, Lcom/paperos/settings/PaperOSGesture;->enableOverlay(Ljava/lang/String;)V

    goto :goto_10

    .line 163
    :cond_d
    invoke-direct {p0, p1}, Lcom/paperos/settings/PaperOSGesture;->disableOverlay(Ljava/lang/String;)V

    .line 165
    :goto_10
    const/4 v1, 0x1

    return v1
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 4
    .param p1, "bundle"  # Landroid/os/Bundle;

    .line 32
    invoke-super {p0, p1}, Lcom/android/settings/BaseSettingsPreferenceFragment;->onCreate(Landroid/os/Bundle;)V

    .line 34
    invoke-virtual {p0}, Lcom/paperos/settings/PaperOSGesture;->getPreferenceScreen()Landroidx/preference/PreferenceScreen;

    move-result-object v0

    const-string v1, "Monet Control"

    invoke-virtual {v0, v1}, Landroidx/preference/PreferenceScreen;->setTitle(Ljava/lang/CharSequence;)V

    .line 37
    invoke-direct {p0}, Lcom/paperos/settings/PaperOSGesture;->initializeMonetPackages()V

    .line 40
    invoke-direct {p0}, Lcom/paperos/settings/PaperOSGesture;->setupGlobalMonetSwitch()V

    .line 43
    invoke-direct {p0}, Lcom/paperos/settings/PaperOSGesture;->setupIndividualMonetSwitches()V

    .line 44
    return-void
.end method
