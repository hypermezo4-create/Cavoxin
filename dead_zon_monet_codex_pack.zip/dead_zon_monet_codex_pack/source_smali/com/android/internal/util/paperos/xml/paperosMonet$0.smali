# classes13.dex

.class public final synthetic Lcom/android/internal/util/paperos/xml/paperosMonet$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/preference/Preference$OnPreferenceChangeListener;


# instance fields
.field public final synthetic f$0:Lcom/android/internal/util/paperos/xml/paperosMonet;


# direct methods
.method public synthetic constructor <init>(Lcom/android/internal/util/paperos/xml/paperosMonet;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/paperos/xml/paperosMonet$0;->f$0:Lcom/android/internal/util/paperos/xml/paperosMonet;

    return-void
.end method


# virtual methods
.method public final onPreferenceChange(Landroidx/preference/Preference;Ljava/lang/Object;)Z
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/android/internal/util/paperos/xml/paperosMonet$0;->f$0:Lcom/android/internal/util/paperos/xml/paperosMonet;

    invoke-virtual {v0, p1, p2}, Lcom/android/internal/util/paperos/xml/paperosMonet;->lambda$setupGlobalMonetSwitch$0$com-android-internal-util-paperos-xml-paperosMonet(Landroidx/preference/Preference;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method
